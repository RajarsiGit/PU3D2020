<?php include('templates/header.php');

  require_once "constants.php";

  $myFile = "data.json";
  $arr_data = array();
  $jsondata = file_get_contents($myFile);
  $arr_data = json_decode($jsondata, true);

  $name = $arr_data[0]['name'];
  $email = $arr_data[0]['email'];
  $qualification = $arr_data[0]['qualification'];
  $designation = $arr_data[0]['designation'];
  $add = $arr_data[0]['address']; 
  $phone = $arr_data[0]['phone'];
  $intend = $arr_data[0]['intend'];
  $accom = $arr_data[0]['accomodation'];
  $calc = $arr_data[0]['amount'];

//$razorpay_payment_id = "";
  $email_message = "";
  $headers = "";
  $email_from = "noreply@pu3d.epizy.com";
  $email_res_subject = "Registration Confirmation";

  $conn = mysqli_connect('sql213.epizy.com', 'epiz_25235366', 'Dq6qEkTmRZUrN', 'epiz_25235366_form');
  if(!$conn)
  {
    die('Connection failed!'.mysqli_error($conn));
  }
  
  $sql = "INSERT INTO form VALUES(null,'$name','$qualification','$designation','$add','$phone','$email','$intend','$accom','$calc');";

  if(mysqli_query($conn, $sql))
  {
    $email_message .= "<html><body><h1>3RD NATIONAL CONFERENCE ON DRUG DISCOVERY & DEVELOPMENT - 3D 2020</h1><h3>March 6 - 7, 2020<br>At the Convention cum Cultural Centre<br>PEC Bus Stop, SH 49,<br>Pillaichavady,<br>Puducherry - 605014</h3>";

      $email_message .= "<h4>Thank you for registering with us!<br>Your partial registration is confirmed! Your form details are given below:<h4>";

      $email_message .= "Name: <b>".$name_str."</b><br>";
      $email_message .= "Qualification: <b>".$qualification."</b><br>";
      $email_message .= "Designation: <b>".$designation."</b><br>";
      $email_message .= "Name and Address of institution: <b>".$add_str."</b><br>";
      $email_message .= "Phone: <b>".$phone_str."</b><br>";
      $email_message .= "Email: <b>".$email."</b><br>";
      $email_message .= "You intend to: <b>".$intend_str."</b><br>";
      $email_message .= "Your accomodation requirment: <b>".$accom."</b><br>";
      $email_message .= "Your pending payment amount: ₹ <b>".$calc."/-</b><br>";
      $email_message .= "<h2>Please pay this at the registration desk on the day of the event.</h2>";

      $email_message .= "Please show us this email during spot registration for easier confirmation of your registration.<br><br>";

      $email_message .= "<b>Department of Biochemistry & Molecular Biology<br>Pondicherry University<br>R.V.Nagar, Kalapet,<br>Puducherry - 605014</b></body></html>";

      $headers  = 'MIME-Version: 1.0' . "\r\n";
      $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
      $headers .= 'From: ' . $email_from . "\r\n" . 'Reply-To: ' . $email_from . "\r\n" . 'X-Mailer: PHP/' . phpversion();

      mail($email, $email_res_subject, $email_message, $headers);
  }
  else
  {
    echo mysqli_error($conn);
    echo "<script type='text/javascript'>alert('Sorry! Please try again!');</script>";
  }
?>
<section class="showcase">
   <div class="container">
    <div class="text-center">
      <h1 class="display-3">Thank You!</h1>
      <p class="lead">Your payment has been received successfully. Please check your mail for further details.</p>
      <hr>
      <p>
        Having trouble? <a href="mailto:pu3d2020@gmail.com">Contact us</a>
      </p>
      <p class="lead">
        <button class="btn btn-primary btn-sm" type="submit" onclick="window.close()">Continue to homepage</button>
      </p>
    </div>
    </div>
</section>
<br><br><br><br><br><br>
<?php include('templates/footer.php');?>