<?php

	$email_from = "noreply@pu3d.000webhostapp.com";
    $email_res_subject = "Registration Confirmation";

	$conn = mysqli_connect('localhost', 'root', '', 'id12592007_pu3d');
	if(!$conn)
	{
		die('Connection failed!'.mysqli_error($conn));
	}

	$name = $_POST['q8_fullName8'];

	$qualification = $_POST['q43_qualification'];
	$designation = $_POST['q48_designation'];

	$add = $_POST['q34_institutionName'];
	

	$phone = $_POST['q12_phoneNumber12'];


	$email = $_POST['q38_email38'];

	$intend = $_POST['q46_iIntend'];

	$accom = $_POST['q47_doYou'];

	$calc = $_POST['q49_calculation'];

	$name_str = implode(" ", $name);
	$add_str = implode(", ", $add);
	$phone_str = implode(" ", $phone);
	$intend_str = implode(", ", $intend);
	
	$sql = "INSERT INTO form VALUES(null,'$name_str','$qualification','$designation','$add_str','$phone_str','$email','$intend_str','$accom','$calc');";

	if(mysqli_query($conn, $sql))
	{
		echo "<script type='text/javascript'>alert('Record Added Successfully!');</script>";	
	}
	else
	{
		echo mysqli_error($conn);
		echo "<script type='text/javascript'>alert('Sorry! Please try again!');</script>";
	}

	$email_message = "3rd National Conference on Drug Discovery & Development - 3D 2020\nMarch 6 - 7, 2020\nAt the Convention cum Cultural Centre\nPEC Bus Stop, SH 49,\nPillaichavady,\nPuducherry - 605014";

	$email_message .= "Thank you for registering with us!\nYour partial registration is confirmed! Your form details are given below:\n\n";

    $email_message .= "Name: ".$name_str."\n";
    $email_message .= "Qualification: ".$qualification."\n";
    $email_message .= "Designation: ".$designation."\n";
    $email_message .= "Name and Address of institution: ".$add_str."\n";
    $email_message .= "Phone: ".$phone_str."\n";
    $email_message .= "Email: ".$email."\n";
    $email_message .= "You intend to: ".$intend_str."\n";
    $email_message .= "Your accomodation requirment: ".$accom."\n";
    $email_message .= "Your pending payment at the time of on spot registration: ".$calc."\n\n\n";

    $email_message .= "Please show us this email during spot registration for easier confirmation of your registration.\n\n";

    $email_message .= "Department of Biochemistry & Molecular Biology\nPondicherry University\nR.V.Nagar, Kalapet,\nPuducherry - 605014";
 
	$headers = 'From: '.$email_from."\r\n".
	'Reply-To: '.$email_from."\r\n" .
	'X-Mailer: PHP/' . phpversion();

	@mail($email, $email_res_subject, $email_message, $headers);

	echo "<script>window.close();</script>";
?>